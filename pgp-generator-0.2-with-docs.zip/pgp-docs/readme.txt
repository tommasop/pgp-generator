Version 0.2 
* Primary keys are automatically identified
* Bug fixes 

Limitations and constraints
* does not perform delete operations
* tables involved must be indexed with a primary keys

Coming Soon:
* Getters will incorporate foreign keys
* Creating an online generator to customize installation process

